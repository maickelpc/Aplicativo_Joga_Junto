<?php

namespace App\Http\Controllers;

use App\UsuarioEvento;
use Illuminate\Http\Request;

class UsuarioEventoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UsuarioEvento  $usuarioEvento
     * @return \Illuminate\Http\Response
     */
    public function show(UsuarioEvento $usuarioEvento)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UsuarioEvento  $usuarioEvento
     * @return \Illuminate\Http\Response
     */
    public function edit(UsuarioEvento $usuarioEvento)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UsuarioEvento  $usuarioEvento
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UsuarioEvento $usuarioEvento)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UsuarioEvento  $usuarioEvento
     * @return \Illuminate\Http\Response
     */
    public function destroy(UsuarioEvento $usuarioEvento)
    {
        //
    }
}
