<?php

namespace App\Http\Controllers;

use App\LocalEsporte;
use Illuminate\Http\Request;

class LocalEsporteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\LocalEsporte  $localEsporte
     * @return \Illuminate\Http\Response
     */
    public function show(LocalEsporte $localEsporte)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\LocalEsporte  $localEsporte
     * @return \Illuminate\Http\Response
     */
    public function edit(LocalEsporte $localEsporte)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\LocalEsporte  $localEsporte
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LocalEsporte $localEsporte)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\LocalEsporte  $localEsporte
     * @return \Illuminate\Http\Response
     */
    public function destroy(LocalEsporte $localEsporte)
    {
        //
    }
}
