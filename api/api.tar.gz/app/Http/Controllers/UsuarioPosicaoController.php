<?php

namespace App\Http\Controllers;

use App\UsuarioPosicao;
use Illuminate\Http\Request;

class UsuarioPosicaoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UsuarioPosicao  $usuarioPosicao
     * @return \Illuminate\Http\Response
     */
    public function show(UsuarioPosicao $usuarioPosicao)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UsuarioPosicao  $usuarioPosicao
     * @return \Illuminate\Http\Response
     */
    public function edit(UsuarioPosicao $usuarioPosicao)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UsuarioPosicao  $usuarioPosicao
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, UsuarioPosicao $usuarioPosicao)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UsuarioPosicao  $usuarioPosicao
     * @return \Illuminate\Http\Response
     */
    public function destroy(UsuarioPosicao $usuarioPosicao)
    {
        //
    }
}
